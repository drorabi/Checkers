#include "Damka.h"


void LoadBoard(char* filename, Board board) // This function loads the board from the file to the game
{
	int i, row, col, j;
	unsigned char tempRow[2], mask = 0XC0, tool;

	FILE* f = fopen(filename, "rb");
	checkIfFileOpen(f);

	for (row = 0; row < BOARD_SIZE; row++)
	{
		j = 0;
		fread(&tempRow, sizeof(unsigned char), 2, f);
		for (col = 0; col < BOARD_SIZE; col++)
		{
			if (col == 4)
				j = 0;
			if (col < 4)
				i = 0;
			else
				i = 1;

			tool = ((tempRow[i] << j) & mask) >> 6;
			j += 2;
			if (tool == 0X0)
				board[row][col] = ' ';

			if (tool == 0X2)
				board[row][col] = 'B';

			if (tool == 0X1)
				board[row][col] = 'T';
		}
	}
	fclose(f);
}