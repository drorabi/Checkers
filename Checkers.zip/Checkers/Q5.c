#include "Damka.h"


void storeBoard(Board board, char* filename) // This function saves the current position of the board to the file
{
	int i, row, col;
	unsigned char tempRow[2], maskForT = 0X1, maskForB = 0X2;
	FILE* f = fopen(filename, "wb");
	checkIfFileOpen(f);

	for (row = 0; row < BOARD_SIZE; row++)
	{
		tempRow[0] = 0X0;
		tempRow[1] = 0X0;

		for (col = 0; col < BOARD_SIZE; col++)
		{
			if (col < 4)
				i = 0;
			else
				i = 1;

			if (board[row][col] == 'T')
				tempRow[i] = (tempRow[i] << 2) | maskForT; // insert 'T' bits to BYTE

			if (board[row][col] == 'B')
				tempRow[i] = (tempRow[i] << 2) | maskForB;  // insert 'B' bits to BYTE

			if (board[row][col] == ' ')
				tempRow[i] = (tempRow[i] << 2); // insert empty cell bits to BYTE
		}
		fwrite(tempRow, sizeof(unsigned char), 2, f);
	}
	fclose(f);
}