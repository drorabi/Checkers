#pragma once 
// Define
#define _CRT_SECURE_NO_WARNINGS
#define BOARD_SIZE 8
#define LEFT 0
#define RIGHT 1
#define END_PROGRAM -1
// include
#include <stdlib.h>
#include <stdio.h>

// Structs

typedef unsigned char Board[BOARD_SIZE][BOARD_SIZE];

typedef unsigned char Player;

typedef struct _checkerPos
{
	char row, col;
} checkerPos;

typedef struct _SingleSorceMovesTreeNode
{
	Board board;
	checkerPos* pos;
	unsigned short  total_captures_so_far;
	struct _SingleSorceMovesTreeNode* next_move[2];
} SingleSorceMovesTreeNode;

typedef struct _SingleSorceMovesTree
{
	SingleSorceMovesTreeNode* source;
} SingleSorceMovesTree;

typedef struct _SingleSourceMovesListCell {
	checkerPos* position;
	unsigned short captures;
	struct  _SingleSourceMovesListCell* next;
}SingleSourceMovesListCell;

typedef struct _SingleSourceMovesList {
	SingleSourceMovesListCell* head;
	SingleSourceMovesListCell* tail;
}SingleSourceMovesList;

typedef struct _multipleSourceMovesListCell {
	SingleSourceMovesList* single_source_moves_list;
	struct _multipleSourceMovesListCell* next;
}MultipleSourceMoveListCell;

typedef struct _multipleSourceMovesList {
	MultipleSourceMoveListCell* head;
	MultipleSourceMoveListCell* tail;
}MultipleSourceMoveList;


// Function declerations - General
void checkAllocation(void* ptr); // Generic memory Allocation check
void checkIfFileOpen(FILE* file); // Checks whether the file was opened or not

// Function declerations - Q1
SingleSorceMovesTree* FindSingleSourceMoves(Board board, checkerPos* src); // main function
SingleSorceMovesTree* checkRoutesForTPlayer(Board board, checkerPos* src); // creating tree for T player and using recursive function
SingleSorceMovesTree* checkRoutesForBPlayer(Board board, checkerPos* src); // creating tree for B player and using recursive function 
SingleSorceMovesTreeNode* createTreeNode(short* counter, Board board, checkerPos* src); // create TreeNode
void createTreeForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);  // main function for tree creating for T player
void createTreeForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter); // main function for tree creating for B player
SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerLeftNoCapture(Board board, checkerPos* src);  // update board and chckerPos for T player to the left no capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerRightNoCapture(Board board, checkerPos* src);  // update board and chckerPos for T player to the right no capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerRightWithCapture(short* counter, Board board, checkerPos* src);  // update board and chckerPos for T player to the right with capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerLeftWithCapture(short* counter, Board board, checkerPos* src);   // update board and chckerPos for T player to the left with capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerLeftNoCapture(Board board, checkerPos* src);  // update board and chckerPos for B player to the left no capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerRightNoCapture(Board board, checkerPos* src);  // update board and chckerPos for B player to the right no capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerRightWithCapture(short* counter, Board board, checkerPos* src);  // update board and chckerPos for B player to the right with capture
SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerLeftWithCapture(short* counter, Board board, checkerPos* src); // update board and chckerPos for B player to the left with capture
void pawnIsAtTheEndOfTheBoardForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter); // the 3 options for a pawn is at the end of the board for B player
void pawnIsAtTheEndOfTheBoardForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter); //the 3 options for a pawn Is At The End Of The Board For T Player
void friendlyPawnOnTheLeftForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);  // the 3 options for a friendly Pawn On The Left For B Player
void friendlyPawnOnTheLeftForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);  // the 3 options for a friendly Pawn On The Left For T Player
void availableCellOnTheLeftForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);  //the 3 options for a available Cell On The Left For B Player
void availableCellOnTheLeftForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);  //the 3 options for a available Cell On The Left For T Player
void enemyOnTheLeftForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);   //the 3 options for a enemy On The Left For B Player
void enemyOnTheLeftForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter);   //the 3 options for a enemy On The Left For T Player

// Function declerations - Q2
SingleSourceMovesList* FindSingleSourceOptimalMove(SingleSorceMovesTree* moves_tree); // This function creates a list of the best route from the tree
SingleSourceMovesList* makeEmpayList(); // make empty list
SingleSourceMovesListCell* createListCell(unsigned short captures, checkerPos* Pos); // create list cell
SingleSorceMovesTreeNode* checkWhereRouteIsLonger(SingleSorceMovesTreeNode* left, SingleSorceMovesTreeNode* right); //check how many steps if captures sre equal
void FindOptimalRoute(SingleSourceMovesList* list, SingleSorceMovesTreeNode* source); // This function finds the optimal route recursively
void insertCellToTail(SingleSourceMovesList* list, SingleSourceMovesListCell* cell);  // insert cell to tail
void insertCellToEmptyList(SingleSourceMovesList* list, SingleSourceMovesListCell* cell); // insert cell to empty list
int levelCounterRec(SingleSorceMovesTreeNode* source);  // check how many steps if captures sre equal
void FreeTree(SingleSorceMovesTreeNode* source); // This function frees the memory allocation of tree

// Function declerations - Q3
MultipleSourceMoveList* FindAllPossiblePlayersMoves(Board board, Player player); // This function creates list of all the available moves the player can play
MultipleSourceMoveList* createMultipleSourceMovesList(); // This function creates an empty multiple source move list
void insertCellToTailOfList(MultipleSourceMoveList* list, MultipleSourceMoveListCell* cell); // This function inserts a given cell to the end of the list
MultipleSourceMoveListCell* createMultipleSourceMoveListCell(SingleSorceMovesTree* tree); // This function creates a multiple source move list cell

// Function declerations - Q4
void Turn(Board board, Player player); // This function gets a board and a player and makes a move for him
SingleSourceMovesListCell* getBestMoveFromList(MultipleSourceMoveList* AllMovesList); //  This function get list of all the possible moves of  player and decides which one of them is the best move, based on the number of captures
void movePlayer(Board board, Player player, SingleSourceMovesListCell* bestMove, void(*rightWithCapture)(Board board, checkerPos* src), void(*rightNoCapture)(Board board, checkerPos* src), void(*leftWithCapture)(Board board, checkerPos* src), void(*leftNoCapture)(Board board, checkerPos* src)); // This function gets a player and relevant functions in order to move him on the board
void freeList(SingleSourceMovesList* lst); // This function frees the single source move list
void freeListOfLists(MultipleSourceMoveList* lst); // This function frees the list of multiple source move list (list of lists)

void dataUpdateTPlayerLeftNoCapture(Board board, checkerPos* src); // Update T player move left no capture
void dataUpdateBPlayerLeftNoCapture(Board board, checkerPos* src); // Update B player move left no capture
void dataUpdateTPlayerRightNoCapture(Board board, checkerPos* src); // Update T player move right no capture
void dataUpdateBPlayerRightNoCapture(Board board, checkerPos* src); // Update B player move right no capture
void dataUpdateTPlayerRightWithCapture(Board board, checkerPos* src); // Update T player move right with capture
void dataUpdateBPlayerRightWithCapture(Board board, checkerPos* src); // Update B player move right with capture
void dataUpdateTPlayerLeftWithCapture(Board board, checkerPos* src); // Update T player move left with capture
void dataUpdateBPlayerLeftWithCapture(Board board, checkerPos* src); // Update B player move left with capture

// Function declerations - Q5
void storeBoard(Board board, char* filename); // This function saves the current position of the board to the file

// Function declerations - Q6
void LoadBoard(char* filename, Board board); // This function loads the board from the file to the game

// Function declerations - Q7
void playGame(Board board, Player starting_player); // This function activates a game between the cumputer and himself
void printBoard(Board board); // This function prints the board
int checkIfGameOver(Board board, Player player); // This function checks if the game is over or not
int gotToEnd(Board board, Player player, char row); // This function checks if the player got to the end of the board
int noMoreCheckers(Board board, Player player); // This function checks if the player is out of pawns

