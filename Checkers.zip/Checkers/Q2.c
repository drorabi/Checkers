#include "Damka.h"

SingleSourceMovesList* FindSingleSourceOptimalMove(SingleSorceMovesTree* moves_tree) // This function creates a list of the best route from the tree
{
	if (moves_tree == NULL)  // no route
		return NULL;
	SingleSourceMovesList *list = makeEmpayList();
	FindOptimalRoute(list, moves_tree->source); // checking routes and building the list
	FreeTree(moves_tree->source);
	free(moves_tree);
	return list;
}

void FindOptimalRoute(SingleSourceMovesList* list, SingleSorceMovesTreeNode* source) // This function finds the optimal route recursively
{
	if (source->next_move[LEFT] == NULL && source->next_move[RIGHT] == NULL) // end of route
	{
		insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
		return;
	}
	if (source->next_move[LEFT] && source->next_move[RIGHT] == NULL)  // route continue only to the left
	{
		if (source->total_captures_so_far == source->next_move[LEFT]->total_captures_so_far)  // no captures
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			insertCellToTail(list, createListCell(source->next_move[LEFT]->total_captures_so_far, source->next_move[LEFT]->pos));
			return;
		}
		else
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			FindOptimalRoute(list, source->next_move[LEFT]);
		}
	}
	if (source->next_move[RIGHT] && source->next_move[LEFT] == NULL)   // route continue only to the right
	{
		if (source->total_captures_so_far == source->next_move[RIGHT]->total_captures_so_far)   // no captures
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			insertCellToTail(list, createListCell(source->next_move[RIGHT]->total_captures_so_far, source->next_move[RIGHT]->pos));
			return;
		}
		else
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			FindOptimalRoute(list, source->next_move[RIGHT]);
		}
	}
	if (source->next_move[LEFT] && source->next_move[RIGHT])  // route continues to right and left
	{
		if (source->total_captures_so_far == source->next_move[LEFT]->total_captures_so_far && source->total_captures_so_far == source->next_move[RIGHT]->total_captures_so_far)  // no capture to left and no captuer to right
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			insertCellToTail(list, createListCell(source->next_move[LEFT]->total_captures_so_far, source->next_move[LEFT]->pos));
			return;
		}
		if (source->next_move[LEFT]->total_captures_so_far > source->next_move[RIGHT]->total_captures_so_far) // capture only to left
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			FindOptimalRoute(list, source->next_move[LEFT]);
		}
		if (source->next_move[LEFT]->total_captures_so_far < source->next_move[RIGHT]->total_captures_so_far)  // capture only to left
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			FindOptimalRoute(list, source->next_move[RIGHT]);
		}
		if (source->next_move[LEFT]->total_captures_so_far == source->next_move[RIGHT]->total_captures_so_far)  // capture to both sides, need to check where route is longer
		{
			insertCellToTail(list, createListCell(source->total_captures_so_far, source->pos));
			FindOptimalRoute(list, checkWhereRouteIsLonger(source->next_move[LEFT], source->next_move[RIGHT]));
		}
	}
}

SingleSorceMovesTreeNode* checkWhereRouteIsLonger(SingleSorceMovesTreeNode* left, SingleSorceMovesTreeNode* right) //check how many steps if captures sre equal
{
	if (levelCounterRec(right) > levelCounterRec(left))
		return right;
	else
		return left;
}

int levelCounterRec(SingleSorceMovesTreeNode* source)  // check how many steps if captures sre equal
{
	if (source->next_move[RIGHT] == NULL && source->next_move[RIGHT] == NULL)
		return 1;
	else
	{
		int left = 0, right = 0;
		if (source->next_move[LEFT])
			left = levelCounterRec(source->next_move[LEFT]);
		if (source->next_move[RIGHT])
			right = levelCounterRec(source->next_move[RIGHT]);
		return (1 + (max(left, right)));
	}
}




SingleSourceMovesList* makeEmpayList()  // make empty list
{
	SingleSourceMovesList* list=(SingleSourceMovesList*)malloc(sizeof(SingleSourceMovesList));
	checkAllocation(list);
	list->head = NULL;
	list->tail = NULL;
	return list;
}

SingleSourceMovesListCell* createListCell(unsigned short captures, checkerPos* pos) // create list cell
{
	SingleSourceMovesListCell* cell;
	cell = (SingleSourceMovesListCell*)malloc(sizeof(SingleSourceMovesListCell));
	checkAllocation(cell);
	cell->captures = captures;
	cell->position = (checkerPos*)malloc(sizeof(checkerPos));
	checkAllocation(cell->position);
	cell->position->col = pos->col;
	cell->position->row = pos->row;
	cell->next = NULL;
	return cell;
}

void insertCellToEmptyList(SingleSourceMovesList* list, SingleSourceMovesListCell* cell) // insert cell to empty list
{
	list->head = cell;
	list->tail = cell;
	return;
}

void insertCellToTail(SingleSourceMovesList* list, SingleSourceMovesListCell* cell)  // insert cell to tail
{
	if (list->head == NULL)
		insertCellToEmptyList(list, cell);
	else
	{
		list->tail->next = cell;
		list->tail = cell;
	}
}


void FreeTree(SingleSorceMovesTreeNode* source) // This function frees the memory allocation of tree
{
	if (source != NULL)
	{
		free(source->pos);
		FreeTree(source->next_move[LEFT]);
		FreeTree(source->next_move[RIGHT]);
		free(source);
	}
}
