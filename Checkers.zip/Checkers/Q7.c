#include "Damka.h"


void playGame(Board board, Player starting_player) // This function activates a game between the cumputer and himself
{
	int firstTurn = 1;
	Player curr_player = starting_player;
	printBoard(board);
	while (!checkIfGameOver(board, curr_player))
	{
		if (!firstTurn)
		{
			if (curr_player == 'T')
				curr_player = 'B';
			else
				curr_player = 'T';
		}
		firstTurn = 0;

		if (curr_player == 'T')
			printf("player TOP_DOWN's turn\n");
		else
			printf("player BOTTOM_UP's turn\n");
		Turn(board, curr_player);
	}
}

void printBoard(Board board) // This function prints the board
{
	char row = 'A';
	int col = 1, i, j;
	printf("+-+-+-+-+-+-+-+-+-+\n");
	printf("+ |1|2|3|4|5|6|7|8| \n");
	for (i = 0; i < BOARD_SIZE; i++)
	{
		printf("+-+-+-+-+-+-+-+-+-+\n");
		printf("|%c|", row);
		for (j = 0; j < BOARD_SIZE; j++)
			printf("%c|", board[i][j]);
		printf("\n");
		row = (char)row + 1;
	}
	printf("+-+-+-+-+-+-+-+-+-+\n");
}

int checkIfGameOver(Board board, Player player) // This function checks if the game is over or not
{
	Player secondPlayer;
	char row;

	if (player == 'T')
	{
		secondPlayer = 'B';
		row = 'H';
	}
	else
	{
		secondPlayer = 'T';
		row = 'A';
	}
	if (gotToEnd(board, player, row) || noMoreCheckers(board, secondPlayer))
	{
		printf( "Player %c is the winner!\n", player);
		return 1;
	}
	return 0;
}

int gotToEnd(Board board, Player player, char row) // This function checks if the player got to the end of the board
{
	int col;

	if (row == 'H')
		col = 0;
	else
		col = 1;

	for (col; col < BOARD_SIZE; col += 2)
	{
		if (board[row - 'A'][col] == player)
			return 1;
	}
	return 0;
}

int noMoreCheckers(Board board, Player player) // This function checks if the player is out of pawns
{
	int row, col;

	for (row = 0; row < BOARD_SIZE; row++)
	{
		col = 0;
		if (row % 2 == 0)  // even row should start from odd places
		{
			col++;
		}
		for (col; col < BOARD_SIZE; col += 2)
		{
			if (board[row][col] == player) // if relevant pawn
			{
				return 0;
			}
		}
	}
	return 1;
}