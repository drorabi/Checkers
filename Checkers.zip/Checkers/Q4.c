#include "Damka.h"


void Turn(Board board, Player player) // This function gets a board and a player and makes a move for him
{
	MultipleSourceMoveList* AllMovesList = FindAllPossiblePlayersMoves(board, player);
	if (AllMovesList->head == NULL) // player cant move
	{
		free(AllMovesList);
		printf("it's a draw- GAME OVER! ");
		exit(END_PROGRAM);
	}
	SingleSourceMovesListCell* bestMove = getBestMoveFromList(AllMovesList);

	if (player == 'T')
	{
		movePlayer(board, player, bestMove, dataUpdateTPlayerRightWithCapture, dataUpdateTPlayerRightNoCapture, dataUpdateTPlayerLeftWithCapture, dataUpdateTPlayerLeftNoCapture);
	}
	else
	{
		movePlayer(board, player, bestMove, dataUpdateBPlayerRightWithCapture, dataUpdateBPlayerRightNoCapture, dataUpdateBPlayerLeftWithCapture, dataUpdateBPlayerLeftNoCapture);
	}

	freeListOfLists(AllMovesList);
}

SingleSourceMovesListCell* getBestMoveFromList(MultipleSourceMoveList* AllMovesList) //  This function get list of all the possible moves of  player and decides which one of them is the best move, based on the number of captures
{
	MultipleSourceMoveListCell* currMultipleMove = AllMovesList->head;
	SingleSourceMovesListCell* currSingleMove;
	SingleSourceMovesListCell* bestMove = currMultipleMove->single_source_moves_list->head;

	int maxCaptures = 0;

	while (currMultipleMove != NULL)
	{
		currSingleMove = currMultipleMove->single_source_moves_list->tail;

		if (currSingleMove->captures > maxCaptures)
		{
			maxCaptures = currSingleMove->captures;
			bestMove = currMultipleMove->single_source_moves_list->head;
		}
		currMultipleMove = currMultipleMove->next;
	}

	return bestMove;
}

void movePlayer(Board board, Player player, SingleSourceMovesListCell* bestMove, void(*rightWithCapture)(Board board, checkerPos* src), void(*rightNoCapture)(Board board, checkerPos* src), void(*leftWithCapture)(Board board, checkerPos* src), void(*leftNoCapture)(Board board, checkerPos* src)) // This function gets a player and relevant functions in order to move him on the board
{
	SingleSourceMovesListCell* curr = bestMove->next;
	SingleSourceMovesListCell* prev = bestMove;

	printf("%c%c", bestMove->position->row, bestMove->position->col); // print first position

	while (curr)
	{
		printf("%s%c%c","->", curr->position->row, curr->position->col); // print position after a move

		if (curr->captures == 0 && curr->position->col > prev->position->col) // no capture, right
		{
			rightNoCapture(board, prev->position);
		}
		else if (curr->captures == 0 && curr->position->col < prev->position->col) // no capture, left
		{
			leftNoCapture(board, prev->position);
		}
		else if (curr->captures != 0 && curr->position->col > prev->position->col) // capture, right
		{
			rightWithCapture(board, prev->position);
		}
		else if (curr->captures != 0 && curr->position->col < prev->position->col) // capture, left
		{
			leftWithCapture(board, prev->position);
		}
		prev = curr;
		curr = curr->next;
	}
	printf("\n");
	return;
}

void freeList(SingleSourceMovesList* lst) // This function frees the single source move list
{
	SingleSourceMovesListCell* curr = lst->head, *next;

	while (curr)
	{
		next = curr->next;
		free(curr->position);
		free(curr);
		curr = next;
	}
}

void freeListOfLists(MultipleSourceMoveList* lst) // This function frees the list of multiple source move list (list of lists)
{
	MultipleSourceMoveListCell* curr = lst->head, *next;

	while (curr)
	{
		next = curr->next;
		freeList(curr->single_source_moves_list);
		curr = next;
	}
}


// board update functions
void dataUpdateTPlayerLeftNoCapture(Board board, checkerPos* src) // Update T player move left no capture
{
	board[src->row-'A'][src->col-'1'] = ' ';
	src->col--;
	src->row++;
	board[src->row-'A'][src->col-'1'] = 'T';
}

void dataUpdateBPlayerLeftNoCapture(Board board, checkerPos* src) // Update B player move left no capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
}

void dataUpdateTPlayerRightNoCapture(Board board, checkerPos* src) // Update T player move right no capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
}

void dataUpdateBPlayerRightNoCapture(Board board, checkerPos* src) // Update B player move right no capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
}

void dataUpdateTPlayerRightWithCapture(Board board, checkerPos* src) // Update T player move right with capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
}

void dataUpdateBPlayerRightWithCapture(Board board, checkerPos* src) // Update B player move right with capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
}

void dataUpdateTPlayerLeftWithCapture(Board board, checkerPos* src) // Update T player move left with capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
}

void dataUpdateBPlayerLeftWithCapture(Board board, checkerPos* src) // Update B player move left with capture
{
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
}

