#include "Damka.h"


void checkAllocation(void* ptr) // Generic memory Allocation check
{
	if (ptr == NULL)
	{
		printf("Allocation error!\n");
		exit(END_PROGRAM);
	}
}

void checkIfFileOpen(FILE* file) // Checks whether the file was opened or not
{
	if (file == NULL)
	{
		printf("Could not open the file!\n");
		exit(END_PROGRAM);
	}
}