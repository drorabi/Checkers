#include "Damka.h"


SingleSorceMovesTree* FindSingleSourceMoves(Board board, checkerPos* src)
{
	if (board[src->row - 'A'][src->col-'1'] == ' ')  // no pawn in the cell
		return NULL;
	if (board[src->row-'A'][src->col-'1'] == 'T')  // pawns that move to a bigger num of row
		return checkRoutesForTPlayer(board, src);
	if (board[src->row - 'A'][src->col - '1'] == 'B')   // pawns that move to a smaller num of row
		return checkRoutesForBPlayer(board, src);
}

SingleSorceMovesTree* checkRoutesForTPlayer(Board board, checkerPos* src)
{
	short counter = 0;
	SingleSorceMovesTree* routeTree = (SingleSorceMovesTree*)malloc(sizeof(SingleSorceMovesTree));
	checkAllocation(routeTree);
	routeTree->source = createTreeNode(&counter, board, src);
	createTreeForTPlayer(routeTree->source, board, src, &counter); // checks the rest of the route and builds the tree in accordance
	return routeTree;
}

SingleSorceMovesTree* checkRoutesForBPlayer(Board board, checkerPos* src)
{
	short counter = 0;
	SingleSorceMovesTree* routeTree = (SingleSorceMovesTree*)malloc(sizeof(SingleSorceMovesTree));
	checkAllocation(routeTree);
	routeTree->source = createTreeNode(&counter, board, src);
	createTreeForBPlayer(routeTree->source, board, src, &counter); // checks the rest of the route and builds the tree in accordance
	return routeTree;
}

SingleSorceMovesTreeNode* createTreeNode(short* counter, Board board,  checkerPos* src) // create tree node
{
	int i, j;
	SingleSorceMovesTreeNode* node = (SingleSorceMovesTreeNode*)malloc(sizeof(SingleSorceMovesTreeNode));
	checkAllocation(node);
	node->pos = ((checkerPos*)malloc(sizeof(checkerPos) * 2));
	checkAllocation(node->pos);
	node->pos->col = src->col;
	node->pos->row = src->row;
	node->total_captures_so_far = (*counter);
	node->next_move[RIGHT] = NULL;
	node->next_move[LEFT] = NULL;
	for (i = 0; i < BOARD_SIZE; i++)
	{
		for (j = 0; j < BOARD_SIZE; j++)
			node->board[i][j] = board[i][j];
	}
	return node;
}

void createTreeForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)
{
		if (src->row - 'A' == 0)
			return;
		if (src->col - '1' == 0 || src->col - '1' == 7) // pawn is at the end of the board
		{
			pawnIsAtTheEndOfTheBoardForBPlayer(source, board, src, counter);
			return;
		}
		else // pawn has 2 potential cells in front
		{
			if (board[src->row - 'A' - 1][src->col - '1' - 1] == 'B')   // friendly pawn on the left
			{
				friendlyPawnOnTheLeftForBPlayer(source, board, src, counter);
				return;
			}
			if (board[src->row - 'A' - 1][src->col - '1' - 1] == ' ') // available cell on the left
			{
				availableCellOnTheLeftForBPlayer( source,  board,   src,  counter);
				return;
			}
			if (board[src->row - 'A' - 1][src->col - '1' - 1] == 'T') // enemy on the left
			{
				enemyOnTheLeftForBPlayer(source, board, src, counter);
				return;
			}
		}
}

void pawnIsAtTheEndOfTheBoardForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)  // pawn is at the end of the board
{

	if (src->col - '1' == 0)  // left end
	{
		if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'B') // friendly pawn on the right
			return;
		if (board[src->row - 'A' - 1][src->col - '1' + 1] == ' ') // available cell on the right build another node and return
		{
			if ((*counter) == 0) // available cell after capture--> return!
				source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightNoCapture(board, src);
			return;
		}
		if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'T')   // enemy on the right
		{
			if (src->row - 'A' == 1 || board[src->row - 'A' - 2][src->col - '1' + 2] != ' ')
				return;
			else  // build a capture node and recursive call to the right
			{
				(*counter)++;
				source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightWithCapture(counter, board, src);
				createTreeForBPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
			}
		}
	}
	if (src->col - '1' == 7)  // right end
	{
		if (board[src->row - 'A' - 1][src->col - '1' - 1] == 'B')  // friendly pawn on the left
			return;
		if (board[src->row - 'A' - 1][src->col - '1' - 1] == ' ') // available cell on the left  build another node and return
		{
			if ((*counter) == 0) // available cell after capture--> return!
				source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftNoCapture(board, src);
			return;
		}
		if (board[src->row - 'A' - 1][src->col - '1' - 1] == 'T') // enemy on the left
		{
			if (src->row - 'A' == 1 || board[src->row - 'A' - 2][src->col - '1' - 2] != ' ')
				return;
			else	// build a capture node and recursive call to the left
			{
				(*counter)++;
				source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftWithCapture(counter, board, src);
				createTreeForBPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
			}
		}
	}

}

void friendlyPawnOnTheLeftForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)  // 
{
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'B') // friendly pawn on both sides
		return;
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == ' ') //  available cell on the right
	{
		if ((*counter) == 0) // available cell after capture--> return!
			source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightNoCapture(board, src);
		return;
	}
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'T')  // enemy on the right
	{
		if (src->row - 'A' == 1 || src->col - '1' == 6 || board[src->row - 'A' + 2][src->col - '1' + 2] != ' ')
			return;
		else  // build a capture node and recursive call to the right
		{
			(*counter)++;
			source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightWithCapture(counter, board, src);
			createTreeForBPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
		}
	}
}

void availableCellOnTheLeftForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter) //  available cell on the left
{
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'B') //friendly pawn on the right 
	{
		if ((*counter) == 0) // available cell after capture--> return!
			source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftNoCapture(board, src);
		return;
	}
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == ' ') //  available cell on both sides
	{
		if ((*counter) == 0) // available cell after capture--> return!
		{
			source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightNoCapture(board, src);
			source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftNoCapture(board, src);
		}
		return;

	}
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'T') // enemy on the right
	{
		if (src->row - 'A' == 1 || src->col - '1' == 6 || board[src->row - 'A' - 2][src->col - '1' + 2] != ' ')
		{
			if ((*counter) == 0)
				source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftNoCapture(board, src);
			return;
		}
		else   // build another node to the left, a capture node and recursive call to the right 
		{
			if ((*counter) == 0)
				source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftNoCapture(board, src);
			(*counter)++;
			source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightWithCapture(counter, board, src);
			createTreeForBPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
		}
	}

}

void enemyOnTheLeftForBPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter) // enemy on the left
{
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'B') //friendly pawn on the right
	{
		if (src->row - 'A' == 1 || src->col - '1' == 1 || board[src->row - 'A' - 2][src->col - '1' - 2] != ' ')
			return;
		else  	// build a capture node and recursive call to the left
		{
			(*counter)++;
			source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftWithCapture(counter, board, src);
			createTreeForBPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
		}
	}
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == ' ') // available cell on the right
	{
		if (src->row - 'A' == 1 || src->col - '1' == 1 || board[src->row - 'A' - 2][src->col - '1' - 2] != ' ') // build node to the right
		{
			if ((*counter) == 0)
				source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightNoCapture(board, src);
			return;
		}
		else  // build another node to the right,  capture node and recursive call to the left
		{
			if ((*counter) == 0)
				source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightNoCapture(board, src);
			(*counter)++;
			source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftWithCapture(counter, board, src);
			createTreeForBPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
		}
	}
	if (board[src->row - 'A' - 1][src->col - '1' + 1] == 'T') // enemy on both sides
	{
		if (src->col - '1' == 1)
		{
			if (src->row - 'A' == 1 || board[src->row - 'A' - 2][src->col - '1' + 2] != ' ')
				return;
			else  // build capture node and recursive call to the right
			{
				(*counter)++;
				source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightWithCapture(counter, board, src);
				createTreeForBPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
			}
		}
		else
		{
			if (src->row - 'A' == 1 || (board[src->row - 'A' - 2][src->col - '1' - 2] != ' ' && src->col-'1'==6) || (board[src->row - 'A' - 2][src->col - '1' - 2] != ' ' && board[src->row - 'A' - 2][src->col - '1' + 2] != ' '))
				return;
			if (board[src->row - 'A' - 2][src->col - '1' - 2] == ' ')  // build capture node and recursive call to the left
			{
				(*counter)++;
				source->next_move[LEFT] = TreeNodeDataUpdateBPlayerLeftWithCapture(counter, board, src);
				createTreeForBPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
			}
			if (board[src->row - 'A' - 2][src->col - '1' + 2] == ' ') // build capture node and recursive call to the right
			{
				(*counter)++;
				source->next_move[RIGHT] = TreeNodeDataUpdateBPlayerRightWithCapture(counter, board, src);
				createTreeForBPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
			}
		}
	}
}

void createTreeForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)
{
	if (src->row - 'A' == 7)
		return;
	if (src->col - '1' == 0 || src->col - '1' == 7) // pawn is at the end of the board
	{
		pawnIsAtTheEndOfTheBoardForTPlayer(source, board, src, counter);
		return;
	}
	else // pawn has 2 potential cells in front
	{
		if (board[src->row - 'A' + 1][src->col - '1' - 1] == 'T')   // friendly pawn on the left
		{
			friendlyPawnOnTheLeftForTPlayer(source, board, src, counter);
			return;
		}
		if (board[src->row - 'A' + 1][src->col - '1' - 1] == ' ') // available cell on the left
		{
			availableCellOnTheLeftForTPlayer(source, board, src, counter);
			return;
		}
		if (board[src->row - 'A' + 1][src->col - '1' - 1] == 'B') // enemy on the left
		{
			enemyOnTheLeftForTPlayer(source, board, src, counter);
			return;
		}
	}
}

void pawnIsAtTheEndOfTheBoardForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter) // pawn is at the end of the bord
{
	if (src->col - '1' == 0)  // left end
	{
		if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'T') // friendly pawn on the right
			return;
		if (board[src->row - 'A' + 1][src->col - '1' + 1] == ' ') //available cell on the right build another node and return
		{
			if ((*counter) == 0) // available cell after capture--> return!
				source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightNoCapture(board, src);
			return;
		}
		if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'B') // enemy on the right
		{
			if (src->row - 'A' == 6 || board[src->row - 'A' + 2][src->col - '1' + 2] != ' ')
				return;
			else  // build a capture node and recursive call to the right
			{
				(*counter)++;
				source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightWithCapture(counter, board, src);
				createTreeForTPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
			}
		}
	}
	if (src->col - '1' == 7)  // right end
	{
		if (board[src->row - 'A' + 1][src->col - '1' - 1] == 'T') // friendly pawn on the left
			return;
		if (board[src->row - 'A' + 1][src->col - '1' - 1] == ' ') //available cell on the left build another node and return
		{
			if ((*counter) == 0) // available cell after capture--> return!
				source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftNoCapture(board, src);
			return;
		}
		if (board[src->row - 'A' + 1][src->col - '1' - 1] == 'B') // enemy on the left
		{
			if (src->row - 'A' == 6 || board[src->row - 'A' + 2][src->col - '1' - 2] != ' ')
				return;
			else	// build a capture node and recursive call to the left
			{
				(*counter)++;
				source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftWithCapture(counter, board, src);
				createTreeForTPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
			}
		}
	}
}

void friendlyPawnOnTheLeftForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)  // friendly pawn to the left
{
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'T')  // friendly pawn on both sides
		return;
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == ' ')  // available cell on the right
	{
		if ((*counter) == 0) // available cell after capture--> return!
			source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightNoCapture(board, src);
		return;
	}
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'B') // enemy on the right
	{
		if (src->row - 'A' == 6 || src->col - '1' == 6 || board[src->row - 'A' + 2][src->col - '1' + 2] != ' ')
			return;
		else  // build a capture node and recursive call to the right
		{
			(*counter)++;
			source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightWithCapture(counter, board, src);
			createTreeForTPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
		}
	}
}

void availableCellOnTheLeftForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)  // available cell on the left
{
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'T')  // friendly pawn on the right
	{
		if ((*counter) == 0) // available cell after capture--> return!
			source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftNoCapture(board, src);
		return;
	}
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == ' ') // available cell on both sides
	{
		if ((*counter) == 0) // available cell after capture--> return!
		{
			source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightNoCapture(board, src);
			source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftNoCapture(board, src);
		}
		return;

	}
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'B') // enemy on the right
	{
		if (src->row - 'A' == 6 || src->col - '1' == 6 || board[src->row - 'A' + 2][src->col - '1' + 2] != ' ')
		{
			if ((*counter) == 0)
				source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftNoCapture(board, src);
			return;
		}
		else   // build another node to the left, a capture node and recursive call to the right 
		{
			if ((*counter) == 0)
				source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftNoCapture(board, src);
			(*counter)++;
			source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightWithCapture(counter, board, src);
			createTreeForTPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
		}
	}
}

void enemyOnTheLeftForTPlayer(SingleSorceMovesTreeNode* source, Board board, checkerPos* src, short* counter)  // enemy on the left
{
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'T')  // friendly pawn on the right
	{
		if (src->row - 'A' == 6 || src->col - '1' == 1 || board[src->row - 'A' + 2][src->col - '1' - 2] != ' ')
			return;
		else  	// build a capture node and recursive call to the left
		{
			(*counter)++;
			source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftWithCapture(counter, board, src);
			createTreeForTPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
		}
	}
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == ' ')  // available cell on the right
	{
		if (src->row - 'A' == 6 || src->col - '1' == 1 || board[src->row - 'A' + 2][src->col - '1' - 2] != ' ') // build node to the right
		{
			if ((*counter) == 0)
				source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightNoCapture(board, src);
			return;
		}
		else  // build another node to the right,  capture node and recursive call to the left
		{
			if ((*counter) == 0)
				source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightNoCapture(board, src);
			(*counter)++;
			source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftWithCapture(counter, board, src);
			createTreeForTPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
		}
	}
	if (board[src->row - 'A' + 1][src->col - '1' + 1] == 'B')  // enemy on both sides
	{
		if (src->col - '1' == 1)
		{
			if (src->row - 'A' == 6 || board[src->row - 'A' + 2][src->col - '1' + 2] != ' ')
				return;
			else  // build capture node and recursive call to the right
			{
				(*counter)++;
				source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightWithCapture(counter, board, src);
				createTreeForTPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
			}
		}
		else
		{
			if (src->row - 'A' == 6 || (board[src->row - 'A' + 2][src->col - '1' - 2] != ' ' && src->col-'1'==6) || (board[src->row - 'A' + 2][src->col - '1' - 2] != ' ' && board[src->row - 'A' + 2][src->col - '1' + 2] != ' '))
				return;
			if (board[src->row - 'A' + 2][src->col - '1' - 2] == ' ')  // build capture node and recursive call to the left
			{
				(*counter)++;
				source->next_move[LEFT] = TreeNodeDataUpdateTPlayerLeftWithCapture(counter, board, src);
				createTreeForTPlayer(source->next_move[LEFT], source->next_move[LEFT]->board, source->next_move[LEFT]->pos, counter);
			}
			if (board[src->row - 'A' + 2][src->col - '1' + 2] == ' ') // build capture node and recursive call to the right
			{
				(*counter)++;
				source->next_move[RIGHT] = TreeNodeDataUpdateTPlayerRightWithCapture(counter, board, src);
				createTreeForTPlayer(source->next_move[RIGHT], source->next_move[RIGHT]->board, source->next_move[RIGHT]->pos, counter);
			}
		}
	}
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerLeftNoCapture(Board board, checkerPos* src) // updating all data before and after applying to treeNode for T player (no capture) to the left
{
	short num = 0;
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
	node = createTreeNode(&num, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'T';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerLeftNoCapture(Board board, checkerPos* src)  // updating all data before and after applying to treeNode for B player (no capture) to the left
{
	short num = 0;
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
	node = createTreeNode(&num, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'B';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerRightNoCapture(Board board, checkerPos* src)  // updating all data before and after applying to treeNode for T player (no capture) to the right
{
	short num = 0;
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
	node = createTreeNode(&num, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'T';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerRightNoCapture(Board board, checkerPos* src)  // updating all data before and after applying to treeNode for B player (no capture) to the right
{
	short num = 0;
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
	node = createTreeNode(&num, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'B';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerRightWithCapture(short* counter, Board board, checkerPos* src)  // updating all data before and after applying to treeNode for T player capture to the right
{
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
	node = createTreeNode(counter, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'T';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerRightWithCapture(short* counter, Board board, checkerPos* src)  // updating all data before and after applying to treeNode for B player capture to the right
{
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
	node = createTreeNode(counter, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'B';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateTPlayerLeftWithCapture(short* counter, Board board, checkerPos* src) // updating all data before and after applying to treeNode for T player capture to the left
{
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
	node = createTreeNode(counter, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
	src->col++;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'T';
	return node;
}

SingleSorceMovesTreeNode* TreeNodeDataUpdateBPlayerLeftWithCapture(short* counter, Board board, checkerPos* src) // updating all data before and after applying to treeNode for B player capture to the left
{
	SingleSorceMovesTreeNode* node;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col--;
	src->row--;
	board[src->row - 'A'][src->col - '1'] = 'B';
	node = createTreeNode(counter, board, src);
	board[src->row - 'A'][src->col - '1'] = ' ';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'T';
	src->col++;
	src->row++;
	board[src->row - 'A'][src->col - '1'] = 'B';
	return node;
	return node;
}
