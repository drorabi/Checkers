#include "Damka.h"


MultipleSourceMoveList* FindAllPossiblePlayersMoves(Board board, Player player) // This function creates list of all the available moves the player can play
{
	MultipleSourceMoveList* list = createMultipleSourceMovesList();
	checkerPos* currPos = (checkerPos*)malloc(sizeof(checkerPos));
	checkAllocation(currPos);
	int i, j;
	char row = 'A';

	for (i = 0; i < BOARD_SIZE; i++)
	{
		j = 0;
		if (i % 2 == 0)  // row with even index should start from odd columns
		{
			j++;
		}
		currPos->row = row;
		for (j; j < BOARD_SIZE; j += 2)
		{
			currPos->col = j + 1 + '0';
			if (board[i][j] == player) // if pawn of the relevant player
			{
				SingleSorceMovesTree* tree_of_moves = FindSingleSourceMoves(board, currPos);
				if (tree_of_moves->source->next_move[LEFT] != NULL || tree_of_moves->source->next_move[RIGHT] != NULL)// if there is an available move
				{
					insertCellToTailOfList(list, createMultipleSourceMoveListCell(tree_of_moves));
				}
			}
			currPos->row = row;
		}
		row++;
	}
	return list;
}

MultipleSourceMoveList* createMultipleSourceMovesList() // This function creates an empty multiple source move list
{
	MultipleSourceMoveList* list;

	list = (MultipleSourceMoveList*)malloc(sizeof(MultipleSourceMoveList));
	checkAllocation(list);

	list->head = list->tail = NULL;
	return list;
}

void insertCellToTailOfList(MultipleSourceMoveList* list, MultipleSourceMoveListCell* cell) // This function inserts a given cell to the end of the list
{
	if (list->head == NULL)// if empty list
	{
		list->head = list->tail = cell;
	}
	else
	{
		list->tail->next = cell;
		list->tail = cell;
	}
}

MultipleSourceMoveListCell* createMultipleSourceMoveListCell(SingleSorceMovesTree* tree) // This function creates a multiple source move list cell
{
	MultipleSourceMoveListCell* cell;
	cell = (MultipleSourceMoveListCell*)malloc(sizeof(MultipleSourceMoveListCell));
	checkAllocation(cell);
	cell->single_source_moves_list = FindSingleSourceOptimalMove(tree);
	cell->next = NULL;

	return cell;
}

